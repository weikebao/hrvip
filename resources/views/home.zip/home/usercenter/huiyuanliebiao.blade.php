<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no" />
    <title>会员中心</title>
    <link href="/shop/css/style.css" rel="stylesheet" />
    <link href="/shop/css/media.css" rel="stylesheet" />

    <script type="text/javascript" src="http://libs.baidu.com/jquery/1.9.1/jquery.min.js"></script>
    <script type="text/javascript" src="/shop/js/index.js"></script>
    <script type="text/javascript" src="/shop/js/jquery-1.8.3.js"></script>

</head>
<style>
    .main .m_right{width: 1000px;}
    .top_box{width: 720px;margin:0 auto;height:32px;background: #f4f4f4;text-align: center;line-height: 32px;font-size: 12px;color:#585857;}
    .top_box select{margin-right:6px;height:20px;}
    .top_box input[type='text']{height:20px;padding-left:5px;}
    .top_box button{width:21px;height:20px;vertical-align: middle;border:none;background: url("/shop/images/sousuo_icon_03.jpg") no-repeat;}
    .con4 a{padding-right:28px;background: url("/shop/images/chakan_icon_03.jpg") no-repeat center right;color:#000;font-size: 20px;}

    .pagination{padding:0 0 30px;text-align: center;margin-top:20px;}
    .pagination li{display: inline-block;width: 80px;height:30px;line-height: 30px;text-align: center;border: 1px solid #cdcdcd;background: #fff;}
    .pagination a{color:#62e810;display: block;}
</style>
<script type="text/javascript">
    //预先加载分页的个数如果分页的栏目太多自动的省略中间的部分
    $(function(){
        var length = $('.pagination li').length-2;
        var num = length-1;
        if(length>3){
            //隐藏一部分数据
           $('.pagination li').each(function(){
            if(($(this).index()>2) && ($(this).index()<num)){
                // 将这些数据进行隐藏
                $(this).css('display','none');
            }
           })
        }
    })
</script>
<body id="mulu">
@include('layout.members.nav')
<div class="banner"></div>
<div class="main clear">
    <div class="title">
        欢迎进入北京新纪元红日会员页面<span>分配会员</span>页面
    </div>
    <h1 class="tit_01">会员中心</h1>
    <@include('layout.members.left_nav')
    <div class="m_right">
        <form class="top_box">
            搜索:&nbsp;
            {{csrf_field()}}
            <input type="text" value="" placeholder="请输入要查找的人员姓名"/>
            <button type="button"></button>
            <input type="hidden" name="zuojiedian" value="{{$ding['zuojiedian']}}">
            <input type="hidden" name="youjiedian" value="{{$ding['youjiedian']}}">
            <input type="hidden" name="sanjiedian" value="{{$ding['sanjiedian']}}">
        </form>
        <script type="text/javascript">
            //点击按钮查询相应的人员
            $(function(){$('form button').click(function(){
                var name = $(this).prev('input').val();
                var zuojiedian = $(this).next('input[name=zuojiedian]').val();
                var youjiedian = $(this).next('input[name=zuojiedian]').next('input[name=youjiedian]').val();
                var sanjiedian = $(this).next('input[name=zuojiedian]').next('input[name=youjiedian]').next('input[name=sanjiedian]').val();
                var _token = $('input[name="_token"]').val();
                if(name!=''){
                    $.ajax({
                        url:'/members/sousuo',
                        data:{'name':name,'_token':_token},
                        type:'post',
                        dataType:'json',
                        success:function(mes){
                            if(mes==1){
                                alert('您搜索的会员姓名不存在!');
                            }else{
                                $('.sousuo').empty();
                                //隐藏分页效果
                                $('.pagination').remove();
                                    var  xiaofeis = '';
                                    var tianjia = '';
                                    var tiaojian = '';
                                    var fid = mes.id;
                                 //判断这个会员的所在位置
                                 var  tuipath = mes.tuipath.split(',')[1];
                                 if(tuipath==zuojiedian){
                                    xiaofeis='一部门'
                                 }else if(tuipath==youjiedian)
                                 {
                                    xiaofeis='二部门'
                                 }else if(tuipath==sanjiedian){
                                    xiaofeis='三部门'
                                 }
if((mes.zuojiedian==null || mes.youjiedian==null)||((mes.zuoqujian>=375) && (mes.youqujian>=375) && mes.sanjiedian==null)){
tianjia = '<a style="color:green;">添加<input type="hidden" name="fid" value='+mes.id+'></a>';
                                    }else{
                                        tianjia ='两侧已满';
                                    }
                                    if(mes.sanqujian!=0){
                                        tiaojian = '<option value="3">三部门</option>';
                                    }else{
                                        tiaojian='';
                                    }
                                    $('.sousuo').append('<tr><td>'+mes.id+'</td><td>'+mes.name+'</td><td>'+mes.phone+'</td><td>'+mes.zuoqujian+'</td><td>'+mes.youqujian+'</td><td>'+mes.sanqujian+'</td><td>'+xiaofeis+'</td><td class="click">'+tianjia+'</td><td><select style="min-width: 65px" name="chakan"><option >选择查看</option><option value="1">一部门</option><option value="2">二部门</option>'+tiaojian+'<select><input type="hidden" name="id" value="'+fid+'"></td></tr>\
                                        ');
                            }
                        }
                    })
                }else{
                    alert('请输入要查找的人员姓名');
                }
            })
            })
        </script>
        <table class="con4">
            <thead>
            <tr>
                <th colspan="8" class="tit_01"><div>会员信息</div></th>
            </tr>
            <tr style="height:10px;"></tr>

            <tr>
                <th class="tit_02">ID</th>
                <th class="tit_02">姓名</th>
                <th class="tit_02">电话</th>
                <th class="tit_02">一部门</th>
                <th class="tit_02">二部门</th>
                <th class="tit_02">三部门</th>
                <th class="tit_02">所在大部</th>
                <th class="tit_02">添加会员</th>
                <th class="tit_02">查看</th>
            </tr>
            </thead>
            <tbody class="sousuo">
            @foreach($res as $v)
            <tr>
                <td>{{$v['id']}}</td>
                <td>{{$v['name']}}</td>
                <td>{{$v['phone']}}</td>
                <td>{{$v['zuoqujian']}}</td>
                <td>{{$v['youqujian']}}</td>
                <td>{{$v['sanqujian']}}</td>
                <td>
                    @if(explode(',',$v['tuipath'])[1]==$ding['zuojiedian'])
                        一部门
                    @elseif(explode(',',$v['tuipath'])[1]==$ding['youjiedian'])
                        二部门
                    @elseif((explode(',',$v['tuipath'])[1]==$ding['sanjiedian'])&&$ding['sanjiedian']!='')
                        三部门
                    @endif
                </td>
                <td class="click">@if(($v['zuojiedian']=='' || $v['youjiedian']=='')||(($v['zuoqujian']>=375) && ($v['youqujian']>=375) && $v['sanjiedian']==''))<a  style="color:green;">添加<input type="hidden" name="fid" value="{{$v['id']}}"></a>@else两侧已满@endif</td>
                <td><select style="min-width: 65px" name="chakan">
                        <option >选择查看</option>
                        <option value='1'>一部门</option>
                        <option value='2'>二部门</option>
                        @if($v['sanqujian']!=0)
                        <option value='3'>三部门</option>
                        @endif
                    <select>
                    <input type="hidden" name="id" value="{{$v['id']}}">
                </td>
            </tr>
            @endforeach
            </tbody>

        </table>
        <!-- <ul class="page" style="padding-top:30px;">
                <li><a href="javascript:;"><</a></li>
                <li class="ac"><a href="javascript:;">1</a></li>
                <li><a href="javascript:;">2</a></li>
                <li><a href="javascript:;">3</a></li>
                <li><a href="javascript:;">9</a></li>
                <li><a href="javascript:;">10</a></li>
                <li><a href="javascript:;">></a></li>
        </ul> -->
        {!! $res->render() !!}
    </div>

</div>

<div class="footer">
    <p class="p1">@ L’Oreal China 红日（中国）有限公司版权所有&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;沪ICP备08100043号-34 </p>
</div>
<script type="text/javascript">
    //点击按钮进行跳转
    $(function(){
        $('.click a').live('click',function(){
            var fid = $(this).find('input').val();
            // 进行网页的跳转
            location.href="/members/addcustomer/"+fid;
        })
        //点击根据部门来查看他的下属会员人员
        $('.sousuo').find('select[name=chakan]').live('change',function(){
            //获取选择查看的部门的值
            var oid = $(this).val();
            //获取选择查看的这个人的ID
            var id = $(this).next('input[name=id]').val();
            var _token = $('input[name="_token"]').val();
            //发送ajax
            $.ajax({
                url:'/members/qujian',
                data:{'oid':oid,'id':id,'_token':_token},
                type:"post",
                dataType:'json',
                success:function(mes){
                   //将数据加载到当前页面
                   if(mes==1){
                    alert('没有查询结果');
                   }else{
                    $('.sousuo').empty();
                    //隐藏分页效果
                    $('.pagination').remove();
                    $.each(mes,function(key,val){
                        var  xiaofeis = '';
                        var tianjia = '';
                        var tiaojian = '';
                        var fid = val.id;
                      //判断人员的部门所在位置
                    if(oid==1){
                        xiaofeis='一部门'
                    }else if(oid==2)
                    {
                        xiaofeis='二部门'
                    }
if((val.zuojiedian==null || val.youjiedian==null)||((val.zuoqujian>=375) && (val.youqujian>=375) && val.sanjiedian==null)){
tianjia = '<a style="color:green;">添加<input type="hidden" name="fid" value='+val.id+'></a>';
                        }else{
                            tianjia ='两侧已满';
                        }

                        if(val.sanqujian!=0){
                            tiaojian = '<option value="3">三部门</option>';
                        }else{
                            tiaojian='';
                        }
                    $('.sousuo').append('<tr><td>'+val.id+'</td><td>'+val.name+'</td><td>'+val.phone+'</td><td>'+val.zuoqujian+'</td><td>'+val.youqujian+'</td><td>'+val.sanqujian+'</td><td>'+xiaofeis+'</td><td class="click">'+tianjia+'</td><td><select style="min-width: 65px" name="chakan"><option >选择查看</option><option value="1">一部门</option><option value="2">二部门</option>'+tiaojian+'<select><input type="hidden" name="id" value="'+fid+'"></td></tr>\
                                    ');
                    })
                   }
                }
            })
            
        })
    })

</script>




</body>
</html>