<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no" />
    <title>会员中心</title>
    <link href="/shop/css/style.css" rel="stylesheet" />
    <link href="/shop/css/media.css" rel="stylesheet" />
    <script type="text/javascript" src="/shop/js/jquery-1.8.3.js"></script>
    <script type="text/javascript" src="/shop/js/index.js"></script>

</head>
<script>
    $(function(){
        $(".con2 .list a,.con2 .biaoge").on("click",function(){
            $(".biaoge").show();
            return false;
        })
        $(document).on("click",function(){
            $(".biaoge").hide();
        })

    })

</script>
<body id="mulu">
@include('layout.members.nav')
<div class="banner"></div>
<div class="main clear">
    <div class="title">
        欢迎进入北京新纪元红日会员<span>客户</span>页面
    </div>
    <h1 class="tit_01">会员中心</h1>
    @include('layout.members.left_nav')
    <div class="m_right">
        <div class="con2">
            <form class="top_box">
                搜索:&nbsp;
                <select>
                    <option>- - -   销售情况   - - -</option>
                </select>
                <input type="text" value="请输入要查找的人员" /><button type="button"></button>
            </form>
            <div class="content">
                <ul class="clear">
                    <li class="list">
                        <h3>张三（一部市场）</h3>
                        <a href="javascript:;"><img src="/shop/images/kehu_pic_03.jpg" /></a>
                    </li>
                    <li class="list">
                        <h3>张三（一部市场）</h3>
                        <a href="javascript:;"><img src="/shop/images/kehu_pic_03.jpg" /></a>
                    </li>
                    <li class="list">
                        <h3>张三（一部市场）</h3>
                        <a href="javascript:;"><img src="/shop/images/kehu_pic_03.jpg" /></a>
                    </li>

                </ul>

            </div>
            <div class="biaoge">
                <table>
                    <tr>
                        <th>姓名ID</th>
                        <th>电话</th>
                        <th>购买次数</th>
                        <th>初次购买时间</th>
                        <th>最后一次时间</th>
                        <th>功能</th>
                    </tr>
                    <tr>
                        <td>张三123</td>
                        <td>13845687544</td>
                        <td>6次</td>
                        <td>07-05-01</td>
                        <td>07-05-01</td>
                        <td><a href="javascript:;" class="btn02">代替支付</a></td>

                    </tr>

                </table>
                <a href="javascript:;" class="btn01"></a>
            </div>

        </div>
    </div>

</div>

<div class="footer">
    <p class="p1">@ L’Oreal China 红日（中国）有限公司版权所有&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;沪ICP备08100043号-34 </p>
</div>

<script src="/shop/js/members_nav_botton_style.js"></script>
</body>
</html>