<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no"/>
    <meta name="MobileOptimized" content="320">
    <meta name="format-detection" content="telephone=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta content="telephone=no" name="format-detection">
    <meta content="yes" name="apple-mobile-web-app-capable" />
    <meta content="black" name="apple-mobile-web-app-status-bar-style" />
    <title>新纪元红日-会员-太阳币充值中心</title>

    <!-- 自定义 -->
    <link rel="stylesheet" href="/shop/assets/swiper/css/swiper-3.4.2.min.css"/>
    <link rel="stylesheet" href="/shop/css/main.css" />
    <link rel="stylesheet" href="/shop/css/Member.css"/>

    <script src="/shop/js/jquery.min.js"></script>
    <script src="/shop/js/Menber.js" type="text/javascript" charset="utf-8"></script>
    <script src="/shop/assets/swiper/js/swiper-3.4.2.jquery.min.js"></script>
    <script src="/shop/js/main.js"></script>
    <link href="/shop/css/style.css" rel="stylesheet" />
    <link href="/shop/css/media.css" rel="stylesheet" />
    <script type="text/javascript" src="/shop/js/jquery-1.8.3.js"></script>
    <script type="text/javascript" src="/shop/js/index.js"></script>
</head>
<body id="mulu">
@include('layout.members.nav')
    <section class="container">
    	 <!--top导航部分-->
    <!--     <section class="topBar">
            <div class="inner">
                <div class="logo" style="background: #404145;">
                    <img src="/shop/images/logo.png">
                </div>
                <div class="menu boxFlex" style="background: #222222;height: 98px;line-height: 98px;">
                    <span class="Flex1 "><a href="">首页</a></span>
                    <span class="Flex1"><a href="">客户</a></span>
                    <span class="Flex1"><a href="">积分赠送</a></span>
                    <span class="Flex1"><a href="">提现</a></span>
                    <span class="Flex1"><a href="">账目流水</a></span>
                    <span class="Flex1"><a href="">投资</a></span>
                    <span class="Flex1"><a href="">个人文档</a></span>
                    <span class="Flex1 on"><a href="">太阳币充值中心</a></span>
                    <span class="Flex1"><a href="">注册</a></span>
                    <span class="Flex1"><a href="">登陆</a></span>
                </div>
            </div>
        </section> -->
<div class="banner"></div>
     <!--    <section class="banner">
            <img src="/shop/images/banner.jpg">
        </section> -->
        
        <div class="huiyuanBox">
        <section class="menmberBox1"style="height: auto;">
        	<div class="menmberCon"style="border: none;">
        		<span class="menmberConleft"style="height: auto;">
        			<div class="menmberConleftText">
        				<p>会员中心</p>
        			</div>
        			<div class="menmberConleftText1">
        				<ul>
        					<li class="menmberConleftText1Li">
        						<a href="">目录</a>
        					</li>
        					<li class="menmberConleftText1Li">
        						<a href="">客户</a>
        					</li>
        					<li class="menmberConleftText1Li">
        						<a href="">积分赠送</a>
        					</li>
        					<li class="menmberConleftText1Li">
        						<a href="">提现</a>
        					</li>
        					<li class="menmberConleftText1Li">
        						<a href="">账目流水</a>
        					</li>
        					<li class="menmberConleftText1Li">
        						<a href="">投资</a>
        					</li>
        					<li class="menmberConleftText1Li">
        						<a href="">个人文档</a>
        					</li>
        					<li class="menmberConleftText1Li">
        						<div class="menmberConleftText1Li-show">
        							<a href="">太阳币中心</a>
        							<i class="menmberConleftText1Li-i"></i>
        						</div>
        						<div class="menmberConleftText1LiHide">
        							<p class="menmberConleftText1LiHide-li bacg"><a href="">佣金兑换太阳币</a></p>
        							<p class="menmberConleftText1LiHide-li"><a href="">太阳币转账</a></p>
        							<p class="menmberConleftText1LiHide-li"><a href="">充值太阳币</a></p>
        						</div>
        					</li>
        				</ul>
        			</div>
        		</span>
        		<span class="menmberConright" style="height: auto;">
        			<div class="menmberConrightCon">
        				<ul>
        					<div class="chongzhitishi">
        						<p>太阳币充值中心，一太阳币等于一元钱</p>
        					</div>
        					<li class="menmberConrightConlLi">
        						<span>充值手机号：</span>
        						<input type="text" name="" id="" value="" placeholder="请输入手机号"/ style="width: 60%;">
        					</li>
        					<!--<div class="searchfangdaBox">
        						<li>找**13832677890</li>
        						<li>找**13832677890</li>
        						<li>找**13832677890</li>
        					</div>-->
        					<li class="menmberConrightConlLi">
        						<span>充值面值：</span>
        						<input type="text" name="" id="" value="" placeholder="请输入数量"/ style="width: 60%;margin-left: 15px;">
        					</li>
        					<li class="menmberConrightConlLi">
        						<span>销售价格：</span>
        						<span style="margin-left: 42px;color: #FC6500;">￥800.00</span>
        					</li>
        				</ul>
        				<div class="taiyangbi-duihuan">
        					<a href="">立即充值</a>
        				</div>
        			</div>
        		</span>
        	</div>
        </section>
        </div>
        
        <section class="footer">
        	<p>@ L’Oreal China 红日（中国）有限公司版权所有    &nbsp;     &nbsp; &nbsp; &nbsp; &nbsp;     沪ICP备08100043号-34 </p>
        </section>
	 </section>
</body>
</html>