<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no" />
    <title>会员中心</title>
    <link href="/shop/css/style.css" rel="stylesheet" />
    <link href="/shop/css/media.css" rel="stylesheet" />
    <script type="text/javascript" src="/shop/js/jquery-1.8.3.js"></script>
    <script type="text/javascript" src="/shop/js/index.js"></script>
     <link rel="stylesheet" href="/shop/assets/swiper/css/swiper-3.4.2.min.css"/>
    <link rel="stylesheet" href="/shop/css/main.css" />
    <link rel="stylesheet" href="/shop/css/Member.css"/>

    <script src="/shop/js/jquery.min.js"></script>
    <script src="/shop/js/Menber.js" type="text/javascript" charset="utf-8"></script>
    <script src="/shop/assets/swiper/js/swiper-3.4.2.jquery.min.js"></script>
    <script src="/shop/js/main.js"></script>
    <link href="/shop/css/style.css" rel="stylesheet" />
    <link href="/shop/css/media.css" rel="stylesheet" />
</head>

<body id="mulu">
@include('layout.members.nav')
<div class="banner"></div>
<div class="main clear">
    <div class="title">
        欢迎进入北京新纪元红日会员<span>修改密码</span>页面
    </div>
    <h1 class="tit_01">会员中心</h1>
    @include('layout.members.left_nav')
    <div class="m_right">
        <section class="menmberBox1" style="height: auto;">
            <div class="menmberCon" style="border: none;">
                <span class="menmberConright" style="height: auto;">
                    <div class="menmberConrightCon">
                        <ul>
                            <div class="chongzhitishi">
                                <p>太阳币充值中心，一太阳币等于一元钱</p>
                            </div>
                            <li class="menmberConrightConlLi">
                                <span>充值手机号：</span>
                                <input type="text" name="" id="" value="" placeholder="请输入手机号"/ style="width: 60%;">
                            </li>
                            <li class="menmberConrightConlLi">
                                <span>充值面值：</span>
                                <input type="text" name="" id="" value="" placeholder="请输入数量"/ style="width: 60%;margin-left: 15px;">
                            </li>
                            <li class="menmberConrightConlLi">
                                <span>销售价格：</span>
                                <span style="margin-left: 42px;color: #FC6500;">￥800.00</span>
                            </li>
                        </ul>
                        <div class="taiyangbi-duihuan">
                            <a href="">立即充值</a>
                        </div>
                    </div>
                </span>
            </div>
        </section>
    </div>
</div>

<div class="footer">
    <p class="p1">@ L’Oreal China 红日（中国）有限公司版权所有&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;沪ICP备08100043号-34 </p>
</div>
<!-- <script type="text/javascript" src="http://libs.baidu.com/jquery/1.9.1/jquery.min.js"></script> -->
<script src="/shop/js/changepass.js"></script>
<script src="/shop/js/members_nav_botton_style.js"></script>

</body>
</html>