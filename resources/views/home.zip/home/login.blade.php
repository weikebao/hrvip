<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no" />
    <title>会员中心</title>
    <link href="/shop/css/style.css" rel="stylesheet" />
    <link href="/shop/css/media.css" rel="stylesheet" />
    <script type="text/javascript" src="/shop/js/jquery-1.8.3.js"></script>
    <script type="text/javascript" src="/shop/js/index.js"></script>

</head>

<body id="mulu">
@include('layout.members.nav')
<div class="banner"></div>
<div class="main clear">
    <div class="title">
        欢迎注册北京新纪元红日商城
    </div>
    <div class="m_left two">
        <img src="/shop/images/denglu_pic_03.jpg" />
    </div>

    <div class="m_right two">
        <form class="con3 denglu" action="/login" method="post">
            {{csrf_field()}}
            <ul>
                <li class="list mima_list clear">
                    <div class="tit">用户名:</div><span class="bz_txt">请输入有效的ID</span>
                    <input type="text" name="name"/>
                </li>
                <li class="list mima_list clear">
                    <div class="tit">密码:</div><span class="bz_txt">请输入有效的密码，由6－12个字符组成。</span>
                    <input  type="password" name="pass" style="background: #fff none repeat scroll 0 0;border: 1px solid #d6d6d6;float: left;font-size: 18px;height: 43px;margin-left: 15px;text-indent: 10px;width: 314px;"/>
                </li>
                <li class="list clear">
                    <div class="tit">验证码:</div>
                    <input type="text" class="duan two" name="captcha"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <img class="ewm_pic"  src="/login/captcha"/>
                    <a href="javascript:;" class="yzm_btn2">看不清<br/>换一个</a>
                </li>

            </ul>
            <button type="button" class="btn_3">立即登录</button>

        </form>
    </div>

</div>

<div class="footer">
    <p class="p1">@ L’Oreal China 红日（中国）有限公司版权所有&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;沪ICP备08100043号-34 </p>
</div>

<!-- <script type="text/javascript" src="http://libs.baidu.com/jquery/1.9.1/jquery.min.js"></script> -->
<script src="\shop\js\jquery-1.8.3.js"></script>
<script src="/shop/js/members_login.js"></script>
<script src="/shop/js/members_nav_botton_style.js"></script>
</body>
</html>