/**
 * Created by Administrator on 2017/4/19.
 */
$(function(){
    $(".nav_btn").on("click",function(){
        $(".nav_s").show();
        return false;
    })
    $(document).on("click",function(){
        $(".nav_s").hide();

    })

})






